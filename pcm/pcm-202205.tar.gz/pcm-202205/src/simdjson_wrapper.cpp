#include "simdjson_wrapper.h"

#ifdef PCM_SIMDJSON_AVAILABLE
#include "simdjson/singleheader/simdjson.cpp"
#endif
